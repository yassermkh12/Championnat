package com.example.championnat;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChampionnatApplication {

	public static void main(String[] args) {
		SpringApplication.run(ChampionnatApplication.class, args);
	}

}
